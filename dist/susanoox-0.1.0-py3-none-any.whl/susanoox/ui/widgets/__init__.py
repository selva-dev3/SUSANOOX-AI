"""Reusable terminal interface widgets."""
