"""Textual terminal interface."""
