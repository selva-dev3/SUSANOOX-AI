"""Application composition."""
