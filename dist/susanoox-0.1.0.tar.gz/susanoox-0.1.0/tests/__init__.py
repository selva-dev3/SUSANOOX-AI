"""Susanoox test suite."""
